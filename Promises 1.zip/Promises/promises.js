// const myPromise = new Promise((resolve, reject) => {
//     fetch("https://api.thecatapi.com/v1/images/search")
//         .then(response => {
//             if (!response.ok) {
//                 reject('The network response was not ok');
//             }
//             return response.json();
//         })
//         .then(data => {
//             resolve(data);
//         })
//         .catch(error => {
//             reject(error);
//         });
// });

// myPromise
//     .then(data => {
//         const imageURL = data[0].url;
//         document.getElementById('image').src = imageURL
//     })
//     .catch(error => console.error(error));

// const myPromise = new Promise((resolve, reject) => {
//     const xhr = new XMLHttpRequest();
//     xhr.open("GET", "https://api.thecatapi.com/v1/images/search");
//     xhr.onload = function () {
//         if (xhr.status === 200) {
//             resolve(JSON.parse(xhr.responseText));
//         } else {
//             reject('The network response was not ok');
//         }
//     };
//     xhr.onerror = function () {
//         reject('Network error occurred');
//     };
//     xhr.send();
// });

// myPromise
//     .then(data => {
//         const imageURL = data[0].url;
//         document.getElementById('image').src = imageURL;
//     })
//     .catch(error => console.error(error));

async function getCatImages() {
    try {
        const response = await fetch("https://api.thecatapi.com/v1/images/search?limit=10");
        if (!response.ok) {
            throw (
                'Network Issue'
            )
        }
        const data = response.json();
        return data;
    } catch (e) {
        console.error(e);
    }
}

function putImage() {
    // const imageURL = getCatImages();
    // console.log(imageURL);
    // document.getElementById('image').src = imageURL;
    getCatImages().then(data => {
        for (let i = 0; i < data.length; i++) {
            const imageURL = data[i].url;
            document.getElementById('image').src = imageURL
        }
    })
}
// putImage()

// getCatImages().then(data => {
//     const imageURL = data.url;
//     document.getElementById('image').src = imageURL
// })